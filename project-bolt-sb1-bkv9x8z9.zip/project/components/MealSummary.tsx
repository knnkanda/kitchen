import { View, Text, StyleSheet, useWindowDimensions } from 'react-native';

interface MealCount {
  firstDay: number;
  subsequent: number;
}

interface MealSummaryProps {
  japanese: MealCount;
  western: MealCount;
}

export default function MealSummary({ japanese, western }: MealSummaryProps) {
  const { width } = useWindowDimensions();
  const isDesktop = width >= 1024;

  const totalJapanese = japanese.firstDay + japanese.subsequent;
  const totalWestern = western.firstDay + western.subsequent;
  const grandTotal = totalJapanese + totalWestern;

  return (
    <View style={[styles.container, isDesktop && styles.containerDesktop]}>
      <Text style={styles.title}>本日の料理準備数</Text>
      
      <View style={styles.grid}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>和食</Text>
          <View style={styles.countGroup}>
            <View style={styles.countItem}>
              <Text style={styles.label}>初回</Text>
              <Text style={styles.value}>{japanese.firstDay}食</Text>
            </View>
            <View style={styles.countItem}>
              <Text style={styles.label}>2回目以降</Text>
              <Text style={styles.value}>{japanese.subsequent}食</Text>
            </View>
            <View style={[styles.countItem, styles.totalItem]}>
              <Text style={styles.label}>合計</Text>
              <Text style={[styles.value, styles.totalValue]}>{totalJapanese}食</Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>洋食</Text>
          <View style={styles.countGroup}>
            <View style={styles.countItem}>
              <Text style={styles.label}>初回</Text>
              <Text style={styles.value}>{western.firstDay}食</Text>
            </View>
            <View style={styles.countItem}>
              <Text style={styles.label}>2回目以降</Text>
              <Text style={styles.value}>{western.subsequent}食</Text>
            </View>
            <View style={[styles.countItem, styles.totalItem]}>
              <Text style={styles.label}>合計</Text>
              <Text style={[styles.value, styles.totalValue]}>{totalWestern}食</Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.grandTotal}>
        <Text style={styles.grandTotalLabel}>総合計</Text>
        <Text style={styles.grandTotalValue}>{grandTotal}食</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  containerDesktop: {
    padding: 24,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 16,
    textAlign: 'center',
  },
  grid: {
    gap: 16,
  },
  section: {
    backgroundColor: '#f8fafc',
    padding: 16,
    borderRadius: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 12,
    textAlign: 'center',
  },
  countGroup: {
    gap: 8,
  },
  countItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#ffffff',
    borderRadius: 6,
  },
  totalItem: {
    marginTop: 4,
    backgroundColor: '#f1f5f9',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  label: {
    fontSize: 15,
    color: '#64748b',
  },
  value: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  totalValue: {
    color: '#2563eb',
  },
  grandTotal: {
    marginTop: 20,
    padding: 16,
    backgroundColor: '#2563eb',
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  grandTotalLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: '#ffffff',
  },
  grandTotalValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#ffffff',
  },
});