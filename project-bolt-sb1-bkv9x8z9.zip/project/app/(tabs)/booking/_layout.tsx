import { Stack } from 'expo-router';

export default function BookingLayout() {
  return (
    <Stack>
      <Stack.Screen 
        name="index"
        options={{ 
          title: '新規予約',
          headerShown: true,
        }} 
      />
      <Stack.Screen 
        name="meal-type"
        options={{ 
          title: 'コース選択',
          headerShown: true,
          presentation: 'card',
        }} 
      />
      <Stack.Screen 
        name="meal-details"
        options={{ 
          title: '予約詳細',
          headerShown: true,
          presentation: 'card',
        }} 
      />
    </Stack>
  );
}