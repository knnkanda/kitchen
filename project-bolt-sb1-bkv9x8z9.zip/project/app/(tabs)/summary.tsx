import { View, StyleSheet, ScrollView, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MealSummary from '@/components/MealSummary';

interface DayMealCounts {
  japanese: {
    firstDay: number;
    subsequent: number;
  };
  western: {
    firstDay: number;
    subsequent: number;
  };
}

export default function SummaryScreen() {
  const { width } = useWindowDimensions();
  const isDesktop = width >= 1024;

  // サンプルデータ - 実際のアプリではAPIやデータベースから取得
  const mealCounts: DayMealCounts = {
    japanese: {
      firstDay: 15,
      subsequent: 8,
    },
    western: {
      firstDay: 12,
      subsequent: 6,
    },
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        style={[styles.content, isDesktop && styles.contentDesktop]}
        showsVerticalScrollIndicator={false}
      >
        <MealSummary
          japanese={mealCounts.japanese}
          western={mealCounts.western}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  contentDesktop: {
    maxWidth: 1200,
    marginHorizontal: 'auto',
    padding: 24,
  },
});