export type MealType = '和食' | '洋食' | 'カウンター';

export interface MealBooking {
  date: string;
  time: string;
  type: MealType;
  guests: number;
  guestName: string;
  notes: string;
  allergies: string;
}

export interface DailyCapacity {
  japanese: number;
  western: number;
  counter: number;
}

export interface Booking {
  id: string;
  checkIn: string;
  checkOut: string;
  totalGuests: number;
  meals: MealBooking[];
}