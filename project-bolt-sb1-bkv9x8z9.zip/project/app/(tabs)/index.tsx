import { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, useWindowDimensions, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Check, Clock, Trash2 } from 'lucide-react-native';

type TimeSlot = {
  time: string;
  japanese: number;
  western: number;
  counter: number;
};

type PreparationStatus = 'pending' | 'in-progress' | 'completed';

interface Reservation {
  id: string;
  time: string;
  type: '和食' | '洋食' | 'カウンター';
  guests: number;
  name: string;
  status: PreparationStatus;
  notes?: string;
  allergies?: string;
  isSubsequentDay?: boolean;
}

export default function KitchenDashboard() {
  const { width } = useWindowDimensions();
  const isDesktop = width >= 1024;

  const [selectedTime, setSelectedTime] = useState<string>('17:30');
  const [reservations, setReservations] = useState<Reservation[]>([
    {
      id: '1',
      time: '17:30',
      type: '和食',
      guests: 2,
      name: '山田様',
      status: 'completed',
      allergies: '海老',
    },
    {
      id: '2',
      time: '17:30',
      type: '洋食',
      guests: 3,
      name: '田中様',
      status: 'in-progress',
    },
    {
      id: '3',
      time: '18:00',
      type: '和食',
      guests: 4,
      name: '佐藤様',
      status: 'pending',
      notes: 'アレルギー対応',
      isSubsequentDay: true,
    },
  ]);
  
  const timeSlots: TimeSlot[] = [
    { time: '17:30', japanese: 4, western: 2, counter: 1 },
    { time: '18:00', japanese: 6, western: 4, counter: 2 },
    { time: '18:30', japanese: 3, western: 2, counter: 1 },
    { time: '19:00', japanese: 5, western: 3, counter: 2 },
    { time: '19:30', japanese: 2, western: 2, counter: 1 },
    { time: '20:00', japanese: 3, western: 1, counter: 1 },
  ];

  const filteredReservations = reservations.filter(r => r.time === selectedTime);

  const getStatusColor = (status: PreparationStatus) => {
    switch (status) {
      case 'completed':
        return '#10b981';
      case 'in-progress':
        return '#f59e0b';
      default:
        return '#ef4444';
    }
  };

  const getStatusText = (status: PreparationStatus) => {
    switch (status) {
      case 'completed':
        return '完了';
      case 'in-progress':
        return '準備中';
      default:
        return '未着手';
    }
  };

  const handleCancelReservation = (id: string) => {
    Alert.alert(
      '予約のキャンセル',
      'この予約をキャンセルしてもよろしいですか？',
      [
        {
          text: 'キャンセル',
          style: 'cancel',
        },
        {
          text: '削除',
          style: 'destructive',
          onPress: () => {
            setReservations(reservations.filter(r => r.id !== id));
          },
        },
      ],
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={[styles.content, isDesktop && styles.contentDesktop]}>
        <View style={styles.header}>
          <Text style={styles.title}>本日の予約状況</Text>
          <View style={styles.timeInfo}>
            <Clock size={20} color="#64748b" />
            <Text style={styles.currentTime}>
              {new Date().toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' })}
            </Text>
          </View>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.timeSlotScroll}>
          {timeSlots.map((slot) => (
            <TouchableOpacity
              key={slot.time}
              style={[
                styles.timeSlot,
                selectedTime === slot.time && styles.timeSlotSelected,
              ]}
              onPress={() => setSelectedTime(slot.time)}>
              <Text style={[
                styles.timeSlotTime,
                selectedTime === slot.time && styles.timeSlotTextSelected,
              ]}>{slot.time}</Text>
              <View style={styles.timeSlotCounts}>
                <Text style={[
                  styles.timeSlotCount,
                  selectedTime === slot.time && styles.timeSlotTextSelected,
                ]}>和: {slot.japanese}</Text>
                <Text style={[
                  styles.timeSlotCount,
                  selectedTime === slot.time && styles.timeSlotTextSelected,
                ]}>洋: {slot.western}</Text>
                <Text style={[
                  styles.timeSlotCount,
                  selectedTime === slot.time && styles.timeSlotTextSelected,
                ]}>カ: {slot.counter}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={styles.reservationList}>
          {filteredReservations.map((reservation) => (
            <View key={reservation.id} style={styles.reservationCard}>
              <View style={styles.reservationHeader}>
                <View style={styles.reservationMain}>
                  <Text style={styles.reservationName}>{reservation.name}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: getStatusColor(reservation.status) }]}>
                    <Text style={styles.statusText}>{getStatusText(reservation.status)}</Text>
                  </View>
                </View>
                <View style={styles.reservationInfo}>
                  <Text style={styles.reservationType}>
                    {reservation.type} - {reservation.guests}名様
                    {reservation.isSubsequentDay && (
                      <Text style={styles.subsequentDay}> (2回目以降)</Text>
                    )}
                  </Text>
                </View>
              </View>
              
              {(reservation.notes || reservation.allergies) && (
                <View style={styles.reservationNotes}>
                  {reservation.allergies && (
                    <Text style={styles.noteText}>⚠️ アレルギー: {reservation.allergies}</Text>
                  )}
                  {reservation.notes && (
                    <Text style={styles.noteText}>📝 {reservation.notes}</Text>
                  )}
                </View>
              )}

              <View style={styles.actionButtons}>
                <TouchableOpacity 
                  style={[styles.actionButton, { backgroundColor: '#3b82f6' }]}>
                  <Check size={16} color="#ffffff" />
                  <Text style={styles.actionButtonText}>準備完了</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.actionButton, { backgroundColor: '#ef4444' }]}
                  onPress={() => handleCancelReservation(reservation.id)}>
                  <Trash2 size={16} color="#ffffff" />
                  <Text style={styles.actionButtonText}>キャンセル</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 16,
    flex: 1,
  },
  contentDesktop: {
    maxWidth: 1200,
    marginHorizontal: 'auto',
    padding: 24,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1e293b',
  },
  timeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  currentTime: {
    fontSize: 16,
    color: '#64748b',
    fontWeight: '600',
  },
  timeSlotScroll: {
    marginBottom: 24,
  },
  timeSlot: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginRight: 12,
    minWidth: 120,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  timeSlotSelected: {
    backgroundColor: '#3b82f6',
    borderColor: '#3b82f6',
  },
  timeSlotTime: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 8,
  },
  timeSlotTextSelected: {
    color: '#ffffff',
  },
  timeSlotCounts: {
    gap: 4,
  },
  timeSlotCount: {
    fontSize: 14,
    color: '#64748b',
  },
  reservationList: {
    flex: 1,
    gap: 16,
  },
  reservationCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  reservationHeader: {
    marginBottom: 12,
  },
  reservationMain: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  reservationInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  reservationName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
  },
  reservationType: {
    fontSize: 16,
    color: '#64748b',
  },
  subsequentDay: {
    color: '#6366f1',
    fontWeight: '500',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
  },
  reservationNotes: {
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  noteText: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 4,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 8,
  },
  actionButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
});