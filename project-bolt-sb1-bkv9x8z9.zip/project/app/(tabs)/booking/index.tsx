import { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function BookingScreen() {
  const [date, setDate] = useState(new Date());
  const [guests, setGuests] = useState('');
  const [showDatePicker, setShowDatePicker] = useState(Platform.OS === 'ios');

  const handleContinue = () => {
    if (!date || !guests) return;
    
    router.push({
      pathname: '/booking/meal-type',
      params: {
        date: date.toISOString(),
        guests,
      },
    });
  };

  const formatDate = (date: Date) => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const year = date.getFullYear().toString().slice(-2);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const dayName = days[date.getDay()];
    return `${year}/${month}/${day}/${dayName}`;
  };

  const onDateChange = (event: any, selectedDate?: Date) => {
    const currentDate = selectedDate || date;
    if (Platform.OS === 'android') {
      setShowDatePicker(false);
    }
    setDate(currentDate);
  };

  const showAndroidDatePicker = () => {
    if (Platform.OS === 'android') {
      setShowDatePicker(true);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.formGroup}>
          <Text style={styles.label}>宿泊日</Text>
          {Platform.OS === 'android' ? (
            <TouchableOpacity
              style={styles.dateButton}
              onPress={showAndroidDatePicker}>
              <Text style={styles.dateButtonText}>
                {formatDate(date)}
              </Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.datePickerContainer}>
              <View style={styles.dateDisplay}>
                <Text style={styles.dateButtonText}>{formatDate(date)}</Text>
              </View>
              <DateTimePicker
                value={date}
                mode="date"
                display="default"
                onChange={onDateChange}
                minimumDate={new Date()}
                locale="ja-JP"
                style={styles.datePicker}
              />
            </View>
          )}
          {Platform.OS === 'android' && showDatePicker && (
            <DateTimePicker
              value={date}
              mode="date"
              display="default"
              onChange={onDateChange}
              minimumDate={new Date()}
            />
          )}
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>食事人数</Text>
          <TextInput
            style={styles.input}
            value={guests}
            onChangeText={setGuests}
            keyboardType="number-pad"
            placeholder="人数を入力"
          />
        </View>

        <TouchableOpacity
          style={[styles.button, (!date || !guests) && styles.buttonDisabled]}
          onPress={handleContinue}
          disabled={!date || !guests}>
          <Text style={styles.buttonText}>次へ</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 16,
    gap: 24,
  },
  formGroup: {
    gap: 8,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  input: {
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    fontSize: 16,
  },
  dateButton: {
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  dateButtonText: {
    fontSize: 16,
    color: '#1e293b',
    textAlign: 'center',
  },
  datePickerContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    overflow: 'hidden',
  },
  dateDisplay: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  datePicker: {
    backgroundColor: '#ffffff',
    height: 50,
  },
  button: {
    backgroundColor: '#3b82f6',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonDisabled: {
    backgroundColor: '#94a3b8',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});