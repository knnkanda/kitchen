import { View, Text, StyleSheet, useWindowDimensions } from 'react-native';
import { DailyCapacity } from '@/types/booking';

interface Props {
  capacity: DailyCapacity;
  date: string;
}

export default function CapacityIndicator({ capacity, date }: Props) {
  const { width } = useWindowDimensions();
  const isDesktop = width >= 1024;

  return (
    <View style={[styles.container, isDesktop && styles.containerDesktop]}>
      <Text style={styles.date}>{date}</Text>
      <View style={styles.grid}>
        <View style={styles.item}>
          <Text style={styles.label}>和食</Text>
          <Text style={styles.value}>{capacity.japanese}席</Text>
        </View>
        <View style={styles.item}>
          <Text style={styles.label}>洋食</Text>
          <Text style={styles.value}>{capacity.western}席</Text>
        </View>
        <View style={styles.item}>
          <Text style={styles.label}>カウンター</Text>
          <Text style={styles.value}>{capacity.counter}席</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  containerDesktop: {
    padding: 24,
  },
  date: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
    color: '#1e293b',
  },
  grid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  item: {
    alignItems: 'center',
    flex: 1,
    padding: 12,
    backgroundColor: '#f8fafc',
    borderRadius: 8,
    marginHorizontal: 4,
  },
  label: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 4,
  },
  value: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
  },
});