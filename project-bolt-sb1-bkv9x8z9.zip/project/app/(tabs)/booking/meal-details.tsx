import { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { MealType } from '@/types/booking';
import { Picker } from '@react-native-picker/picker';

export default function MealDetailsScreen() {
  const params = useLocalSearchParams<{
    date: string;
    guests: string;
    type: MealType;
  }>();

  const [time, setTime] = useState('18:00');
  const [name, setName] = useState('');
  const [notes, setNotes] = useState('');
  const [allergies, setAllergies] = useState('');

  // 朝食と夕食の時間枠を生成
  const generateTimeSlots = () => {
    const slots = [];
    // 朝食時間帯 (6:00-10:00)
    for (let hour = 6; hour <= 10; hour++) {
      for (let minute of ['00', '30']) {
        if (hour === 10 && minute === '30') continue;
        slots.push(`${hour.toString().padStart(2, '0')}:${minute}`);
      }
    }
    // 夕食時間帯 (17:00-22:00)
    for (let hour = 17; hour <= 22; hour++) {
      for (let minute of ['00', '30']) {
        if (hour === 22 && minute === '30') continue;
        slots.push(`${hour.toString().padStart(2, '0')}:${minute}`);
      }
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  const handleSubmit = () => {
    // 予約データを作成
    const reservation = {
      time,
      type: params.type,
      guests: parseInt(params.guests),
      name,
      status: 'pending',
      notes,
      allergies,
      date: new Date(params.date),
    };

    // TODO: 予約データをグローバルステートまたはデータベースに保存
    console.log('New reservation:', reservation);
    
    router.push('/');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content}>
        <View style={styles.formGroup}>
          <Text style={styles.label}>食事時間</Text>
          {Platform.OS === 'ios' ? (
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={time}
                onValueChange={(itemValue) => setTime(itemValue)}
                style={styles.picker}>
                {timeSlots.map((slot) => (
                  <Picker.Item key={slot} label={slot} value={slot} />
                ))}
              </Picker>
            </View>
          ) : (
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={time}
                onValueChange={(itemValue) => setTime(itemValue)}
                style={styles.picker}>
                {timeSlots.map((slot) => (
                  <Picker.Item key={slot} label={slot} value={slot} />
                ))}
              </Picker>
            </View>
          )}
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>お名前</Text>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="例: 山田様"
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>アレルギー</Text>
          <TextInput
            style={styles.input}
            value={allergies}
            onChangeText={setAllergies}
            placeholder="アレルギーがある食材をご記入ください"
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>備考</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={notes}
            onChangeText={setNotes}
            placeholder="その他ご要望があればご記入ください"
            multiline
            numberOfLines={4}
          />
        </View>

        <TouchableOpacity
          style={[styles.button, !name && styles.buttonDisabled]}
          onPress={handleSubmit}
          disabled={!name}>
          <Text style={styles.buttonText}>予約を確定する</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 16,
  },
  formGroup: {
    marginBottom: 24,
    gap: 8,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  input: {
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    fontSize: 16,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  pickerContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    overflow: 'hidden',
  },
  picker: {
    backgroundColor: '#ffffff',
    marginHorizontal: Platform.OS === 'ios' ? 0 : 12,
  },
  button: {
    backgroundColor: '#3b82f6',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonDisabled: {
    backgroundColor: '#94a3b8',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});