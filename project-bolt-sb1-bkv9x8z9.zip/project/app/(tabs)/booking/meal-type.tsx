import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { MealType } from '@/types/booking';

interface GuestMeal {
  type: MealType;
  visitCount: number;
}

export default function MealTypeScreen() {
  const params = useLocalSearchParams<{ date: string; guests: string }>();
  const guestCount = parseInt(params.guests || '1', 10);
  
  const [guestMeals, setGuestMeals] = useState<GuestMeal[]>(
    Array(guestCount).fill({ type: '和食', visitCount: 1 })
  );

  const handleSelectType = (index: number, type: MealType) => {
    const newGuestMeals = [...guestMeals];
    newGuestMeals[index] = { ...newGuestMeals[index], type };
    setGuestMeals(newGuestMeals);
  };

  const handleVisitCount = (index: number, count: number) => {
    const newGuestMeals = [...guestMeals];
    newGuestMeals[index] = { ...newGuestMeals[index], visitCount: count };
    setGuestMeals(newGuestMeals);
  };

  const handleContinue = () => {
    router.push({
      pathname: '/booking/meal-details',
      params: {
        ...params,
        guestMeals: JSON.stringify(guestMeals),
      },
    });
  };

  const renderMealOption = (type: MealType, title: string, description: string, isSelected: boolean, onSelect: () => void) => (
    <TouchableOpacity
      style={[styles.option, isSelected && styles.optionSelected]}
      onPress={onSelect}>
      <View style={styles.optionHeader}>
        <Text style={[styles.optionTitle, isSelected && styles.optionTitleSelected]}>
          {title}
        </Text>
        {isSelected && (
          <View style={styles.selectedIndicator}>
            <Text style={styles.selectedIndicatorText}>✓</Text>
          </View>
        )}
      </View>
      <Text style={[styles.optionDescription, isSelected && styles.optionDescriptionSelected]}>
        {description}
      </Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content}>
        {guestMeals.map((guestMeal, index) => (
          <View key={index} style={styles.guestSection}>
            <Text style={styles.guestTitle}>ゲスト {index + 1}</Text>
            
            <View style={styles.mealTypes}>
              {renderMealOption(
                '和食',
                '和食',
                '旬の食材を使用した日本料理',
                guestMeal.type === '和食',
                () => handleSelectType(index, '和食')
              )}
              {renderMealOption(
                '洋食',
                '洋食',
                'シェフ特製のコース料理',
                guestMeal.type === '洋食',
                () => handleSelectType(index, '洋食')
              )}
              {renderMealOption(
                'カウンター',
                'カウンター',
                'シェフと会話を楽しみながらのお食事',
                guestMeal.type === 'カウンター',
                () => handleSelectType(index, 'カウンター')
              )}
            </View>

            <View style={styles.visitCountContainer}>
              <Text style={styles.visitLabel}>ご利用回数</Text>
              <View style={styles.visitButtons}>
                {[1, 2, 3, 4].map((count) => (
                  <TouchableOpacity
                    key={count}
                    style={[
                      styles.visitButton,
                      guestMeal.visitCount === count && styles.visitButtonSelected,
                    ]}
                    onPress={() => handleVisitCount(index, count)}>
                    <Text
                      style={[
                        styles.visitButtonText,
                        guestMeal.visitCount === count && styles.visitButtonTextSelected,
                      ]}>
                      {count === 4 ? '4回目以降' : `${count}回目`}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        ))}

        <TouchableOpacity style={styles.continueButton} onPress={handleContinue}>
          <Text style={styles.continueButtonText}>次へ</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 16,
  },
  guestSection: {
    marginBottom: 32,
  },
  guestTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 16,
  },
  mealTypes: {
    gap: 12,
  },
  option: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  optionSelected: {
    backgroundColor: '#eff6ff',
    borderColor: '#3b82f6',
  },
  optionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  optionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
  },
  optionTitleSelected: {
    color: '#1d4ed8',
  },
  optionDescription: {
    fontSize: 14,
    color: '#64748b',
  },
  optionDescriptionSelected: {
    color: '#3b82f6',
  },
  selectedIndicator: {
    backgroundColor: '#3b82f6',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedIndicatorText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  visitCountContainer: {
    marginTop: 16,
    gap: 8,
  },
  visitLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  visitButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  visitButton: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    alignItems: 'center',
  },
  visitButtonSelected: {
    backgroundColor: '#3b82f6',
    borderColor: '#3b82f6',
  },
  visitButtonText: {
    fontSize: 14,
    color: '#1e293b',
  },
  visitButtonTextSelected: {
    color: '#ffffff',
  },
  continueButton: {
    backgroundColor: '#3b82f6',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  continueButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});